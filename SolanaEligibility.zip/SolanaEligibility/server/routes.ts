import type { Express } from "express";
import { createServer, type Server } from "http";
import { db } from "@db";
import { tweetInteractions } from "@db/schema";
import cors from "cors";

export function registerRoutes(app: Express): Server {
  // Configure CORS for the production domain
  app.use(cors({
    origin: process.env.NODE_ENV === 'production' 
      ? 'https://nft.deanslist.services'
      : true,
    credentials: true
  }));

  // Store tweet interactions with eligibility criteria
  app.post("/api/tweet-interactions", async (req, res) => {
    try {
      const { 
        walletAddress,
        hasRequiredDeanTokens,
        hasDeansListNFT,
        hasMetCriteria3,
        hasMetCriteria4,
        hasMetCriteria5
      } = req.body;

      if (!walletAddress) {
        return res.status(400).json({ message: "Wallet address is required" });
      }

      await db.insert(tweetInteractions).values({
        walletAddress,
        hasRequiredDeanTokens: !!hasRequiredDeanTokens,
        hasDeansListNFT: !!hasDeansListNFT,
        hasMetCriteria3: !!hasMetCriteria3,
        hasMetCriteria4: !!hasMetCriteria4,
        hasMetCriteria5: !!hasMetCriteria5
      });

      res.status(201).json({ message: "Tweet interaction recorded" });
    } catch (error) {
      console.error("Error recording tweet interaction:", error);
      res.status(500).json({ message: "Failed to record tweet interaction" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}