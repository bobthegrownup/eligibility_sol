import { Button } from "@/components/ui/button";
import { ArrowRightLeft } from "lucide-react";

export function JupiterSwap() {
  return (
    <Button
      onClick={() => {
        window.open('https://jup.ag/swap/SOL-Ds52CDgqdWbTWsua1hgT3AuSSy4FNx2Ezge1br3jQ14a', '_blank');
      }}
      className="w-full mt-2"
      variant="outline"
    >
      <ArrowRightLeft className="mr-2 h-4 w-4" />
      Swap for DEAN
    </Button>
  );
}