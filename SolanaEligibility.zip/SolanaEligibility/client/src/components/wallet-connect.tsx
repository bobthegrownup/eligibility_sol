import { Button } from "@/components/ui/button";
import { useWallet } from "@/lib/wallet";
import { Loader2 } from "lucide-react";

export function WalletConnect() {
  const { wallet, connecting, connect, disconnect, selectedAdapter } = useWallet();

  if (connecting) {
    return (
      <Button disabled className="w-full">
        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
        Connecting...
      </Button>
    );
  }

  if (wallet) {
    return (
      <div className="space-y-4">
        <div className="p-4 bg-muted rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <p className="text-sm font-medium">Connected Wallet</p>
            {selectedAdapter === "phantom" ? (
              <span></span>
            ) : (
              <span></span>
            )}
          </div>
          <p className="text-xs text-muted-foreground break-all">{wallet.publicKey.toString()}</p>
        </div>
        <Button variant="destructive" onClick={disconnect} className="w-full">
          Disconnect
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <Button onClick={() => connect("phantom")} className="w-full">
        Phantom
      </Button>
      <Button onClick={() => connect("solflare")} className="w-full">
        Solflare
      </Button>
    </div>
  );
}