import { Check, X, Loader2, Twitter } from "lucide-react";
import { useWallet } from "@/lib/wallet";
import { useTokenBalance, hasRequiredDeanBalance } from "@/lib/hooks/use-token-balance";
import { useNFTOwnership } from "@/lib/hooks/use-nft-ownership";
import { useFutardsOwnership } from "@/lib/hooks/use-futards-ownership";
import { Button } from "@/components/ui/button";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { JupiterSwap } from "@/components/jupiter-swap";

const REQUIRED_DEAN = 69_000;

export function EligibilityChecklist() {
  const { wallet } = useWallet();
  const { toast } = useToast();
  const { data: deanBalance, isLoading: loadingBalance } = useTokenBalance(wallet?.publicKey ?? null);
  const { data: ownsNFT, isLoading: loadingNFT } = useNFTOwnership(wallet?.publicKey ?? null);
  const { data: ownsFutards, isLoading: loadingFutards } = useFutardsOwnership(wallet?.publicKey ?? null);

  const criteria = [
    {
      id: 1,
      label: `Hold at least ${REQUIRED_DEAN.toLocaleString()} DEAN tokens`,
      completed: hasRequiredDeanBalance(deanBalance),
      loading: loadingBalance,
    },
    {
      id: 2,
      label: "Dean's List NFT Gen 1 Holder",
      completed: ownsNFT,
      loading: loadingNFT,
    },
    {
      id: 3,
      label: "Futard",
      completed: ownsFutards,
      loading: loadingFutards,
    },
    { id: 4, label: "Item 4", completed: false, loading: false },
    { id: 5, label: "Item 5", completed: false, loading: false },
  ];

  const hasAnyCriteriaMet = criteria.some((item) => item.completed);
  const isLoading = criteria.some((item) => item.loading);

  const tweetMutation = useMutation({
    mutationFn: async () => {
      if (!wallet?.publicKey) throw new Error("No wallet connected");

      const res = await fetch("/api/tweet-interactions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          walletAddress: wallet.publicKey.toString(),
          hasRequiredDeanTokens: criteria[0].completed,
          hasDeansListNFT: criteria[1].completed,
          hasMetCriteria3: criteria[2].completed,
          hasMetCriteria4: criteria[3].completed,
          hasMetCriteria5: criteria[4].completed,
        }),
      });

      if (!res.ok) {
        throw new Error("Failed to record tweet interaction");
      }
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to record your tweet interaction",
      });
    },
  });

  const shareToTwitter = async () => {
    try {
      await tweetMutation.mutateAsync();
      const tweetText = encodeURIComponent("I got accepted!");
      window.open(`https://twitter.com/intent/tweet?text=${tweetText}`, '_blank');
    } catch {
      // Error is handled by the mutation
    }
  };

  return (
    <div className="space-y-4">
      {criteria.map((item) => (
        <div
          key={item.id}
          className={`flex items-center justify-between p-4 rounded-lg border ${
            item.completed ? "bg-primary/10 border-primary" : "bg-muted border-muted-foreground/20"
          }`}
        >
          <span className="font-medium">{item.label}</span>
          {item.loading ? (
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          ) : item.completed ? (
            <Check className="h-5 w-5 text-primary" />
          ) : (
            <X className="h-5 w-5 text-muted-foreground" />
          )}
        </div>
      ))}

      {/* Show Jupiter Swap button when DEAN balance is insufficient */}
      {!isLoading && wallet && !hasRequiredDeanBalance(deanBalance) && (
        <JupiterSwap />
      )}

      {!isLoading && hasAnyCriteriaMet && (
        <Button 
          onClick={shareToTwitter}
          disabled={tweetMutation.isPending}
          className="w-full bg-[#1DA1F2] hover:bg-[#1a8cd8]"
        >
          {tweetMutation.isPending ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <Twitter className="mr-2 h-4 w-4" />
          )}
          Share on Twitter
        </Button>
      )}
    </div>
  );
}