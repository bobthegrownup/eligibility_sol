import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { WalletConnect } from "@/components/wallet-connect";
import { EligibilityChecklist } from "@/components/eligibility-checklist";
import { useWallet } from "@/lib/wallet";

export default function Home() {
  const { wallet } = useWallet();

  return (
    <div 
      className="min-h-screen w-full flex flex-col items-center justify-center p-4 relative"
      style={{
        backgroundImage: 'url("/dl2.jpeg")',
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}
    >
      {/* Dark overlay for better readability */}
      <div className="absolute inset-0 bg-black/60" />

      {/* Content */}
      <div className="w-full max-w-2xl space-y-6 relative z-10">
        <h1 className="text-4xl font-bold text-center bg-gradient-to-r from-primary to-purple-400 bg-clip-text text-transparent">
          Solana Eligibility Checker
        </h1>

        <Card className="backdrop-blur-sm bg-background/80">
          <CardHeader>
            <CardTitle>Wallet Connection</CardTitle>
          </CardHeader>
          <CardContent>
            <WalletConnect />
          </CardContent>
        </Card>

        {wallet && (
          <Card className="backdrop-blur-sm bg-background/80">
            <CardHeader>
              <CardTitle>Eligibility Checklist</CardTitle>
            </CardHeader>
            <CardContent>
              <EligibilityChecklist />
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}