import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { Connection, PublicKey } from "@solana/web3.js";
import { PhantomWalletAdapter } from "@solana/wallet-adapter-phantom";
import { SolflareWalletAdapter } from "@solana/wallet-adapter-solflare";

interface WalletContextType {
  wallet: null | { publicKey: PublicKey };
  connecting: boolean;
  connect: (adapterName: "phantom" | "solflare") => Promise<void>;
  disconnect: () => void;
  selectedAdapter: "phantom" | "solflare" | null;
}

const WalletContext = createContext<WalletContextType>({
  wallet: null,
  connecting: false,
  connect: async () => {},
  disconnect: () => {},
  selectedAdapter: null,
});

export function WalletProvider({ children }: { children: ReactNode }) {
  const [wallet, setWallet] = useState<null | { publicKey: PublicKey }>(null);
  const [connecting, setConnecting] = useState(false);
  const [selectedAdapter, setSelectedAdapter] = useState<"phantom" | "solflare" | null>(null);

  const [adapters] = useState(() => ({
    phantom: new PhantomWalletAdapter(),
    solflare: new SolflareWalletAdapter(),
  }));

  useEffect(() => {
    // Try to reconnect to the last used wallet
    const lastUsedWallet = localStorage.getItem("lastUsedWallet") as "phantom" | "solflare" | null;
    if (lastUsedWallet && adapters[lastUsedWallet]) {
      adapters[lastUsedWallet].connect().catch(() => {});
    }

    return () => {
      Object.values(adapters).forEach(adapter => adapter.disconnect());
    };
  }, [adapters]);

  const connect = async (adapterName: "phantom" | "solflare") => {
    try {
      setConnecting(true);
      const adapter = adapters[adapterName];
      await adapter.connect();
      const publicKey = adapter.publicKey;
      if (!publicKey) throw new Error("No public key");
      setWallet({ publicKey });
      setSelectedAdapter(adapterName);
      localStorage.setItem("lastUsedWallet", adapterName);
    } catch (error) {
      console.error(`Failed to connect ${adapterName} wallet:`, error);
    } finally {
      setConnecting(false);
    }
  };

  const disconnect = () => {
    if (selectedAdapter) {
      adapters[selectedAdapter].disconnect();
    }
    setWallet(null);
    setSelectedAdapter(null);
    localStorage.removeItem("lastUsedWallet");
  };

  return (
    <WalletContext.Provider value={{ wallet, connecting, connect, disconnect, selectedAdapter }}>
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet() {
  return useContext(WalletContext);
}