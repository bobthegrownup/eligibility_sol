import { useQuery } from "@tanstack/react-query";
import { Connection, PublicKey } from "@solana/web3.js";

// Complete list of Dean's List NFT mint addresses
const DEANS_LIST_MINTS = [
  "Hav7MUZzUWbqAcbxNhdvRUEvyXAtQpCZprUH4ewDFJoV",
  "CWSj8LDka8uLqaWXc6yDmLE8pAGSXt8iW5z3dJKhTp33",
  "7D7gASJufLttmsTJS2PsDnEmj37GpswFwmM527sfse31",
  "CZwnVCoxcPaPStcJP5L44wR1eEE8RaMVUapHnY16iRfH",
  "BCwWAHQU9UeBBDp9c61eWNRDv8ffkSfECEzxvZA7Y7Jx",
  "VFJ2T3XywVq7pVqqbVYoyynPuBEWNr1zdCzNF1VHvdP",
  "CDqrnXZiP9n3uaYizsqTYo3momjxzy3VfAYr6AckvZ82",
  "Fvpct2qBUuEAcvyZYpemNifmm5jC7DWRBPgbhgk1s1df",
  "7EHhsxCuXUzLT1tgpqhvVsK7g5ETdXsunBTME2Rwy8MY",
  "73tdn6KwPtUWYFHYhwAKZaDJLDi8Gncdqca3t8jngkix",
  "HSB19vAWnKxDpSo1hdKPR8e6QxwDRYgf4jdYPfoUzXwK",
  "Y7EEnLqayf3kmiWCxQmkjCXucZeMAA881TJYt3QsdkX",
  "F2JvBtrpznmR7qVsJeDvtR7CcVoeEwZZ7G6wWSFwpEpP",
  "36Mh4vUiKS149jjb3TebWSr86ybTmuaqqiwWC3mrCofN",
  "Ax2tVK4qgd4FJRE4CNeqmUrZ9vjCwCEXLZqyTze3NdvW",
  "G3ZXdwyRqZXiaAfTTAXYhmdRj86JSfycpnWTgRntj9rM",
  "B5DeZ7s9FLmSMMftwFNtbSWKACW7EjHDh4caYV3oFKks",
  "HAkyxGeQbemNBjzmJ3W8ErHJZUVA4WPbJkT9WT5fyxLn",
  "CNzQZKykCZAkt2a6UJ8SUiuHA8nm2x8MExy4gnFz6y2v",
  "AyAZidfKi1RoJeXPP2g4XeMSHoqaWsPAuRgnikkRiTqn",
  "6hsaZLD3fVgpRH9uiHtZndba44WkFfEoMffWMXgomZfa",
  "5hN8pUk6GSZz4WPkT8pD6wjpwv3ooDN5KZse1gvsGrAL",
  "J3vTW6uSJmyR1vjyYz6DbwawdrDa13QrFxPE6M9yUwx7",
  "CCQcv6yLoXSSfH4iDYrKiFaqicaPebhwfSBFR49HaXcz",
  "81XPdts17zQZo3XFp5r46YgLF66S5sa6MKBpSpTvPMf5",
  "AU5DyBsfKk4AETihKMy929nciuyuWZcMkWxyzERedMGs",
  "FfuJrjSbye8vuwd9fJxFsRCDyyxEguvBzMCUVUmwCbfj",
  "iEC2BYqNYFcg6qvTVQpgv66xa9GiPn1g8fKiHGsJQ8Q",
  "Cp6d81zk1EFCHnZN9BXXRvuBBi2jDzJaBGWf21ue8wRY",
  "yEcfRiK9yjU1CJgdLqZnLyLmgWztwQxa7CuCvBZD8gd",
  "9jRwYxJ2rDg9AZt8s5or5ToZjWvbo7JVcJqYZjNE2aMm",
  "9ua15JxQEHCzyU6e2Rrn9WNhmiz8YekYQAp9Txnpeo9Q",
  "5hNyMfaHdWsZY6V2Ei58Txe8ec4GTM3TwWMrvHZZ6Upi",
  "4d5KmFgB9Qsv2dgrcpffUupKZTW139V73Tq2ssRUNN5y",
  "fpHhGXZK2yPDHPQmmHyC35A7dRHHT6v5qqABwrDyRUv",
  "5XRTbNDo6DybE8pqE6vjyR8Hs2t7h4jdBwSthT9V6URM",
  "6iyY7H4JdBJk5t4aC48EGz23ELdja1EfmBctht95rMmr",
  "AKmHTYNzEaG4ewoWJvWBF99ggKYaMW2zfP3UcwC4z21i",
  "6rvrPB2PUVu2g4pFrA6jV1k9HRqzcD9xHUMieA4xwwGt",
  "2fDeLiLGB46KoeumS3YbuCzbEUYiDfGExX1amBk3X79H",
  "FLd7s7KeJKMhCiuM2q62igfB5tGnTiC38sQzQdKffuPG",
  "13tA8Fzy9zjfGvHEu3FeVqKj6eQBVUSvZDvmUPpL1kDo",
  "BQcR2K88BTfTvs3mm1GTTHdVqRemSicTWmeznRnVh1Yx",
  "GCsm6Jd3Vxgss5b5sKZg4U7FwuxqsWkjSBEAZcnn9oYK",
  "GPzjyCA4Ld5WTfcc5JZtU3mhdeQ9paQetd59SZiQhRFh",
  "9sk2oHjCmdy3KiopUDEcrQtzS4V94aEJzjUwS7AwrD7x",
  "8pxRkioTy2t1BqmEXJtqkRkvrEGVu6bXd3e1FDzTnFvZ",
  "DKGDPV5Sghax6qdd11AfevMGQXWsTT6QMZXswk4jJvff",
  "H6MpcUkZMKqTC4xrA8NwRXf77P4G68DjUaeMeFL7FsnP",
  "6ZNmsGsHowAfDcpeZ7WG7XK9bNRtP4ijavsNdeiUCqKX",
  "ARTy8FdidR7KyZXeHucRGgYgjAHBk12cjgTaLExsfvXQ",
  "HGZcAhHZsWoWCKFS5YczkCDJybw9MKqFBXnCKRyZuai6",
  "FDZ6TAf7snah5LMr6CdgAJVXYs8kaQSqhf5mgAtBCK4U",
  "HhcAgJzsboYAtFNiyGjZXuw3C5gZaefkthgKHR5R7fFt",
  "GGXfCaTfdAJvGPDFsdXau2mjfeJ95D8yfovF5Kmt2y71",
  "AreGTLYsfHNRjfEsphfD9bef9n39TSDrxCnWsCBV8QBC",
  "HrHX133PiQCqURrpPWtq4N3LAKRHjCXLf7q73tP6fBiK",
  "AE4YCDEvPBKdkkFhu9cz8XgxgsyXABm3oCJo7SwbHMvL",
  "CDntDfNXowqQYZpibnAeYY6auFdVTz2mNzENDL2artzM",
  "7i8VTkM3sVCXej968frfifFaesNs8A4S5sbFzUAy8sDA",
  "EtTvhgMAYeQhicN69tNmydMJaYLSYbxUYBDcB7Ez85H7",
  "4NUopnrnoVsFonozJFYHRkzyWs1NqZmtbH6kjmGJxyk7",
  "AH8ujLLohkgLhnDf1S1nuNr2rj3yDwAo4bJ4jio5ZrBM",
  "6BZwpdquBaYBSgo6SRYP23nu1s1g5nQ7QwSoHKagn1h1",
  "CLABDUWJqopXh8AnfQfPHQAhzpCKR5LU4NkkYGYmGfgR",
  "FNBAto8RSgxiigwsFsGx93rNKHhS9E2nnkWwZaD7SSTu",
  "SpGUhuz8JgEcMZDAtiqguJmtTWam3gXmHbmb9sVFUsZ",
  "DQnqNajC3hqmaCwwE7Q53m1zDbMtthQnB55sWLNoa1nX",
  "4nUVA7xsDHWmNtUAeJJ7CqeEd9z3TgHsjtcTMQQAK7SJ",
  "BDq7UQqkCuN9Li7ppgJNg97TNDmPUCQwpAXfzfJM8ugX",
  "8aFhugUshWB8qAcrFVZ7t3o1kUty8HvrvCY27Vx1jiob",
  "9nkoetV3JB2qLJXCEmcHv4QwMirSengTD2CihHvCsQdY",
  "8BtwsA3ry1gsWrD2L7FhZAxnAmaALrNoKTh45Ez5VamH",
  "FGfFa9t75wYUxMVRmoGgKb8YYyVDbuFWak5J1LUNhrQY",
  "8Sf3X4XpPgf66ABJqGE6rXXQzuSGqzMHfvtsDTwdMUZ",
  "HU3p3QiDpBAGrQoxSXxZG89Cgdc3qwSK1CcRefB2HuUR",
  "2JUQrqBXhAQj2ft22Pr64owtk4ujhSxKkLKd2jNfyaxE",
  "7KW6kASq4F61yfYs8X1DM6taBHtJXm6gQeJ4WCH1Yzw1",
  "5Hr46uwfyFJ5FdLm5rVqWPY827m4G7Qu8HTwp4xB2z1F",
  "3UDZctTdGeHG45gPzrstnvvLzMx9ydxRwzy9rBFZzHNb",
  "YnLffr5knDy8oFFkxnXyeCkS5C73CUqzQ45bnvG66MN",
  "FQpmuM2ifAwz7rV8DVh9puwPYSTSz7j6nsjj4jTtm6Ra",
  "EkKN9fs5eewP2h4XAd7JSkoNqXPQQ3J8XpebrNTZtAXL",
  "693ouL6hAvAUWUrYb6VGXhCbRQmX6mZLh8p68BGLYJLP",
  "3czf4nhZtkCj4GwTJQ2jzhTzqmCLT8QNCr8RxRmh2HFk",
  "AwwNvkZisYzgquqiE2RUieiHtgJt5LsGVHUqzTDxJnSx",
  "BrAczkwEasiEFsbHRu2zZLjfVGS3zaEpkgWiAH7h4u1J",
  "841tajo2vnuAY1Lo3fNQcucYjxtN5xyaJFumrUVEMjYf",
  "By9EQzEDEmj9KPu3vChzZJkiqF1hBNzaw7RhQLP5DenU",
  "5ejTporQVo57zseq8p5xnaFrhG11i8SxYzLXdW7Ln8cd",
  "4dmxJaeniJHnVLxu3yaE58eA19Z2PXpteborPvWsz8eG",
  "21YHnistbm2iB8YaFanKxeZhs6KrABU8VCmsLxbV14Q4",
  "jaHA1jNgkt2iBZJpWU1Gt6c2U9WqHMzSsudw9691vCu",
  "CAopyg3zUn67KuXCa8nnFWtmWZRkZucCm2gCKCCdJzV",
  "C5zU42u15HtTv2gxtPHUyguzXH3N6cUPj2zXQkLXz2bc",
  "5mnpGrJps3mpXXnuQdX4HKxqKJGtXUpa2qEE3CYdF6xt",
  "BSw2KzYb7P69bGqPG6UGkskah3ZmtjqF5MXiQgUAVLMF",
  "9UH27oC3zwCUUqyxecsfV4eejQMod7JLGZFrAYjB4ayY",
  "HMmHvyzHyHVk71xWJwypo2zHhKoG1TVw1U5PLruDgEvZ"
].map(mint => new PublicKey(mint));

// Use environment RPC URL with a fallback
const RPC_ENDPOINT = import.meta.env.VITE_SOLANA_RPC_URL || "https://api.mainnet-beta.solana.com";
const connection = new Connection(RPC_ENDPOINT, 'confirmed');

export function useNFTOwnership(walletAddress: PublicKey | null) {
  return useQuery({
    queryKey: ["nft-ownership", walletAddress?.toString()],
    queryFn: async () => {
      if (!walletAddress) return false;

      try {
        console.log("Checking NFT ownership for wallet:", walletAddress.toString());

        // Check ownership for each mint until we find one
        for (const mint of DEANS_LIST_MINTS) {
          try {
            console.log("Checking mint:", mint.toString());
            const accounts = await connection.getTokenAccountsByOwner(walletAddress, {
              mint: mint
            });

            // If we find any account with this mint, return true and stop checking
            if (accounts.value.length > 0) {
              console.log("Found NFT ownership for mint:", mint.toString());
              return true;  // Early return on first match
            }
          } catch (mintError) {
            console.error("Error checking specific mint:", mint.toString(), mintError);
            // If there's an error checking this mint, try the next one
            continue;
          }
        }

        console.log("No NFT ownership found for wallet:", walletAddress.toString());
        return false;
      } catch (error) {
        console.error("Error checking NFT ownership:", error);
        throw error;
      }
    },
    enabled: !!walletAddress,
    refetchInterval: 30000,
    retry: 2,
    staleTime: 10000
  });
}