import { useQuery } from "@tanstack/react-query";
import { Connection, PublicKey, type Commitment } from "@solana/web3.js";
import { TOKEN_PROGRAM_ID } from "@solana/spl-token";

// Use environment RPC URL with a fallback
const RPC_ENDPOINT = import.meta.env.VITE_SOLANA_RPC_URL || "https://api.mainnet-beta.solana.com";

// Create a connection with only the essential configuration
const connection = new Connection(RPC_ENDPOINT);

const DEAN_TOKEN = new PublicKey("Ds52CDgqdWbTWsua1hgT3AuSSy4FNx2Ezge1br3jQ14a");
const REQUIRED_BALANCE = 69_000;

export function useTokenBalance(walletAddress: PublicKey | null) {
  return useQuery({
    queryKey: ["token-balance", walletAddress?.toString()],
    queryFn: async () => {
      if (!walletAddress) return null;

      try {
        // Get token accounts with minimal configuration
        const accounts = await connection.getTokenAccountsByOwner(walletAddress, {
          mint: DEAN_TOKEN
        });

        // If no accounts found, return 0
        if (accounts.value.length === 0) {
          return 0;
        }

        // Get balance of the first account (there should only be one)
        const accountInfo = await connection.getParsedAccountInfo(accounts.value[0].pubkey);
        if (!accountInfo.value || !('parsed' in accountInfo.value.data)) {
          return 0;
        }

        // @ts-ignore - We know the structure of parsed data
        const balance = accountInfo.value.data.parsed.info.tokenAmount.uiAmount;
        return balance || 0;
      } catch (error) {
        console.error("Error fetching token balance:", error);
        return 0;
      }
    },
    enabled: !!walletAddress,
    refetchInterval: 30000, // Reduced from 60000 to match NFT check interval
    retry: 1,
    staleTime: 10000
  });
}

export function hasRequiredDeanBalance(balance: number | null | undefined): boolean {
  if (balance === undefined || balance === null) return false;
  return balance >= REQUIRED_BALANCE;
}