import { pgTable, text, serial, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").unique().notNull(),
  password: text("password").notNull(),
});

export const tweetInteractions = pgTable("tweet_interactions", {
  id: serial("id").primaryKey(),
  walletAddress: text("wallet_address").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  hasRequiredDeanTokens: boolean("has_required_dean_tokens").notNull().default(false),
  hasDeansListNFT: boolean("has_deans_list_nft").notNull().default(false),
  hasMetCriteria3: boolean("has_met_criteria3").notNull().default(false),
  hasMetCriteria4: boolean("has_met_criteria4").notNull().default(false),
  hasMetCriteria5: boolean("has_met_criteria5").notNull().default(false),
});

export const insertUserSchema = createInsertSchema(users);
export const selectUserSchema = createSelectSchema(users);
export const insertTweetInteractionSchema = createInsertSchema(tweetInteractions);
export const selectTweetInteractionSchema = createSelectSchema(tweetInteractions);

export type InsertUser = typeof users.$inferInsert;
export type SelectUser = typeof users.$inferSelect;
export type InsertTweetInteraction = typeof tweetInteractions.$inferInsert;
export type SelectTweetInteraction = typeof tweetInteractions.$inferSelect;